package com.example.gerenciamentodeos.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gerenciamentodeos.AdicionarOrdens;
import com.example.gerenciamentodeos.ListagemClientes;
import com.example.gerenciamentodeos.ListagemOrdens;
import com.example.gerenciamentodeos.R;
import com.example.gerenciamentodeos.entidades.Cliente;
import com.example.gerenciamentodeos.entidades.OrdemServico;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.List;

public class OrdemAdapter extends RecyclerView.Adapter<OrdemAdapter.ViewHolderOrdem> {

    List<OrdemServico> osList;

    public OrdemAdapter(List<OrdemServico> osList) {
        this.osList = osList;
    }

    @NonNull
    @Override
    public OrdemAdapter.ViewHolderOrdem onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View view = layoutInflater.inflate(R.layout.viewholder_ordens, parent, false);

        ViewHolderOrdem holderOrdem = new ViewHolderOrdem(view, parent.getContext());

        return holderOrdem;
    }

    @Override
    public void onBindViewHolder(@NonNull OrdemAdapter.ViewHolderOrdem holder, int position) {

        if( (osList != null) && (osList.size() > 0) ) {
            OrdemServico os = osList.get(position);

            holder.nome_cliente.setText(os.nome_do_cliente);
            holder.modelo.setText(os.modelo_carro);
            holder.placa_carro.setText(os.placa_do_carro);
            holder.os.setText(os.ordem_de_servico);
            holder.descricao.setText(os.descricao);

        }
    }

    @Override
    public int getItemCount() {
        return osList.size();
    }

    public class ViewHolderOrdem extends RecyclerView.ViewHolder{

        public TextView nome_cliente;
        public TextView placa_carro;
        public TextView os;
        public TextView modelo;
        public TextView descricao;

        public ViewHolderOrdem(@NonNull View itemView, final Context context) {
            super(itemView);

            nome_cliente = (TextView)itemView.findViewById(R.id.nome_cliente);
            placa_carro = (TextView)itemView.findViewById(R.id.placa_carro);
            os = (TextView)itemView.findViewById(R.id.ordem_servico);
            modelo = (TextView)itemView.findViewById(R.id.modelo);
            descricao = (TextView)itemView.findViewById(R.id.descricao);
            ImageButton deleteBtn = itemView.findViewById(R.id.deleteOS);

            itemView.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v){

                    if(osList.size() > 0){

                        OrdemServico osSelecionada = osList.get(getLayoutPosition());

                        Intent intent = new Intent(context, AdicionarOrdens.class);
                        intent.putExtra("os_selecionada", (Serializable) osSelecionada);
                    }

                }
            });

            deleteBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    OrdemServico osSelecionado = osList.get(getLayoutPosition());

                    Intent intent = new Intent(context, ListagemOrdens.class);
                    intent.putExtra("delete_os", (Serializable) osSelecionado);

                    context.startActivity(intent);

                }
            });

        }
    }
}
